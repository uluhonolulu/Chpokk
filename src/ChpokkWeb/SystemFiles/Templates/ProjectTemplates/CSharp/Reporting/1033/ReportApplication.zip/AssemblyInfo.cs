﻿//------------------------------------------------------------------
// <copyright company="Microsoft">
//     Copyright (c) Microsoft.  All rights reserved.
// </copyright>
//------------------------------------------------------------------
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// $WinForm_CSharp_AssemblyInfo_GeneralInfo$
[assembly: AssemblyTitle("$projectname$")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("$registeredorganization$")]
[assembly: AssemblyProduct("$projectname$")]
[assembly: AssemblyCopyright("Copyright © $registeredorganization$ $year$")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// $WinForm_CSharp_AssemblyInfo_ComVisible$
[assembly: ComVisible(false)]

// $WinForm_CSharp_AssemblyInfo_Guid$
[assembly: Guid("$guid1$")]

// $WinForm_CSharp_AssemblyInfo_Version$
//
//      $WinForm_CSharp_AssemblyInfo_MajorVersion$
//      $WinForm_CSharp_AssemblyInfo_MinorVersion$
//      $WinForm_CSharp_AssemblyInfo_BuildNumber$
//      $WinForm_CSharp_AssemblyInfo_Revision$
//
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
