﻿#pragma once

namespace $safeprojectname$
{
    public ref class Class1 sealed
    {
    public:
        Class1();
    };
}